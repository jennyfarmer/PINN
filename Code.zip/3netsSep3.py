import sys
import torch
from collections import OrderedDict
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.model_selection import train_test_split
import copy
from numpy.random import default_rng
from timeit import default_timer as timer
from pdb import set_trace
import os
from torch.nn.parameter import Parameter

def scaleValues(values):
    shift = min(values)
    values = values - shift
    scale = max(values)
    values = values / scale
    return values, shift, scale

def unscaleValues(values, shift, scale):
    values = values * scale
    values = values + shift
    return values

# define constants function
def get_const(x, const, depths):
    kappa_list = list()
    rho_list = list()
    cp_list = list()
    thresh = list()
    if type(depths) == float or type(depths) == int:
        thresh = None
    else:
        for i in range(len(depths)):
            if i == 0:
                thresh.append(depths[i])
            else:
                thresh.append(np.sum(depths[:i + 1]))
        thresh.pop(-1)
        const = const[:len(depths)]
    if type(thresh) == type(None):
        kappa_list = [const[0][0]] * int(len(x))
        rho_list = [const[0][1]] * int(len(x))
        cp_list = [const[0][2]] * int(len(x))
    else:
        for i in range(len(x)):
            if len(thresh) == 0:
                kappa_list.append(const[0][0])
                rho_list.append(const[0][1])
                cp_list.append(const[0][2])
                continue
            if x[i].item() < thresh[0]:
                kappa_list.append(const[0][0])
                rho_list.append(const[0][1])
                cp_list.append(const[0][2])
                continue
            if x[i].item() >= thresh[-1]:
                kappa_list.append(const[-1][0])
                rho_list.append(const[-1][1])
                cp_list.append(const[-1][2])
                continue
            for j in range(len(thresh)):
                if x[i].item() >= thresh[j] and x[i].item() < thresh[j + 1]:
                    kappa_list.append(const[j + 1][0])
                    rho_list.append(const[j + 1][1])
                    cp_list.append(const[j + 1][2])
                    break

    kappa = torch.tensor(np.array(kappa_list).reshape(-1, 1), requires_grad = True).float()
    rho = torch.tensor(np.array(rho_list).reshape(-1, 1)).float()
    cp = torch.tensor(np.array(cp_list).reshape(-1, 1)).float()
    kappa = kappa.to(device)
    rho = rho.to(device)
    cp = cp.to(device)
    return kappa, rho, cp


class SigmoidSeparation(torch.nn.Module):
    def __init__(self, shiftN, scaleN, separation):
        super().__init__()
        self.shiftN = Parameter(torch.tensor(shiftN))
        self.scaleN = Parameter(torch.tensor(scaleN))
        self.separation = Parameter(torch.tensor(separation))
#        self.separation = torch.tensor(separation)


    def forward(self, x):        
        x = x.to(device)
        predictionN = self.shiftN + self.scaleN * torch.sigmoid(100000 * (x - self.separation))
        return predictionN

class SigmoidSeparationN(torch.nn.Module):
    def __init__(self, shiftN, scaleN, separation):
        super().__init__()
        self.shiftN = Parameter(torch.tensor(shiftN))
        self.scaleN = Parameter(torch.tensor(scaleN))
        self.separation = Parameter(torch.tensor(separation))
        print('scaleN')
        print(scaleN)


    def forward(self, x):        
        x = x.to(device)
        predictionN = self.shiftN + self.scaleN * torch.sigmoid(100000 * (x - self.separation))
        return predictionN

class SigmoidSeparationK(torch.nn.Module):
    def __init__(self, shiftK, scaleK):
        super().__init__()
        self.shiftK = Parameter(torch.tensor(shiftK))
        self.scaleK = Parameter(torch.tensor(scaleK))


    def forward(self, x):
        x = x.to(device)
        separation = torch.tensor(PINNmodel.sep)
        separation = separation.to(device)
        predictionK = self.shiftK + self.scaleK * torch.sigmoid(10000000000 * (x - separation))
        return predictionK



# Neural Networks
def NN(x, t):
    return dnn(torch.cat([x, t], dim=1))
def NN2(x):
    return dnn2(torch.cat([x], dim=1))
def NN3(x):
    return dnn3(torch.cat([x], dim=1))
def NN4(x):
    return dnn4(torch.cat([x], dim=1))




def pde(x, t, dose):    
    predictNN = NN(x, t)
    u = predictNN[:, 0].reshape(len(predictNN[:, 0]), 1)
    u_t = torch.autograd.grad(u, t, grad_outputs=torch.ones_like(u), retain_graph=True, create_graph=True)[0]
    u_x = torch.autograd.grad(u, x, grad_outputs=torch.ones_like(u), retain_graph=True, create_graph=True)[0]
    u_xx = torch.autograd.grad(u_x, x, grad_outputs=torch.ones_like(u_x), retain_graph=True, create_graph=True)[0]
    u_xx = u_xx.to(device)

    predNu = NN2(x)
    predNuScale = predNu * 10 ** -nuScale
    PINNmodel.sep = dnn2.layers[0].separation.detach().cpu().numpy()

    predKappa = NN3(x)
    predKappaScale = predKappa * 10 ** -kappaScale

    residual = u_t - (predKappaScale * predNuScale * u_xx) - predNuScale * dose
    residual = residual[PINNmodel.idx]
    return residual, u_xx, u_t, predNu.detach().cpu().numpy(), predKappa.detach().cpu().numpy()



def lossFunction():
    optimizer.zero_grad()
    if len(x_d) > 0:
        pred = NN(x_d, t_d)
        predTemp = pred[:, 0].reshape(len(pred[:, 0]), 1)
        lossData = torch.mean((PINNmodel.dTemp - predTemp) ** 2)

    else:
        lossData = torch.zeros(1)

    lossData = lossData.to(device)

    pred = NN(x_ibc, t_ibc)
    predTemp = pred[:, 0].reshape(len(pred[:, 0]), 1)

    lossTemp = torch.mean((PINNmodel.bTemp - predTemp) ** 2)

    pred, PINNmodel.u_xx, PINNmodel.u_t, nu, kappa = pde(x_f, t_f, PINNmodel.dose)

    lossPDE = torch.mean((pred) ** 2)
    loss = PINNmodel.wb * lossTemp + PINNmodel.wf * lossPDE + PINNmodel.wd * lossData
    loss = loss.to(device)


    loss.backward()
    PINNmodel.iter += 1

    if PINNmodel.iter % 100 == 0 or PINNmodel.iter < 100:
        print('Iter {}, Loss: {}, pde: {}, data: {}, bound: {}, nu: {} {}, kappa: {} {}, sep: {}'.format(PINNmodel.iter, loss.item(),
                                                                      lossPDE.item(), lossData.item(), lossTemp.item(),
                                                                      min(nu), max(nu), min(kappa), max(kappa), PINNmodel.sep, flush=True))
    return loss



def lossFunctionNu():
    optimizer2.zero_grad()
    pred, PINNmodel.u_xx, PINNmodel.u_t, nu, kappa = pde(x_f, t_f, PINNmodel.dose)
    lossPDE = torch.mean((pred) ** 2)
    loss = lossPDE
    loss.backward()
    if PINNmodel.iter % 100 == 0 or PINNmodel.iter < 100:
        print('Iter {}, Loss: {}, nu: {} {}, kappa: {} {}, sep: {}'.format(PINNmodel.iter, loss.item(),                                                                      
                                             min(nu), max(nu), min(kappa), max(kappa), PINNmodel.sep, flush=True))
    return loss

def lossFunctionKappa():
    optimizer3.zero_grad()
    pred, PINNmodel.u_xx, PINNmodel.u_t, nu, kappa = pde(x_f, t_f, PINNmodel.dose)
    lossPDE = torch.mean((pred) ** 2)
    loss = lossPDE
    loss.backward()
    if PINNmodel.iter % 100 == 0 or PINNmodel.iter < 100:
        print('Iter {}, Loss: {}, nu: {} {}, kappa: {} {}, sep: {}'.format(PINNmodel.iter, loss.item(),                                                                      
                                             min(nu), max(nu), min(kappa), max(kappa), PINNmodel.sep, flush=True))
    return loss


def lossFunctionSep():
    optimizer4.zero_grad()
    pred, nu, kappa = pde(x_f, t_f, PINNmodel.dose)
    lossPDE = torch.mean((pred) ** 2)
    loss = lossPDE
    loss.backward()
    if PINNmodel.iter % 100 == 0 or PINNmodel.iter < 100:
        print('Iter {}, Loss: {}, nu: {} {}, kappa: {} {}, sep: {}'.format(PINNmodel.iter, loss.item(),                                                                      
                                             min(nu), max(nu), min(kappa), max(kappa), PINNmodel.sep, flush=True))
    return loss



def writeResults(prediction, true, file, label):
    prediction = prediction.detach().cpu().numpy()
    prediction_df = pd.DataFrame(prediction, columns=['Guess'])
    prediction_df['True'] = true
    p = prediction.reshape(prediction.size, 1)
    score = r2_score(true, prediction)
    mre = np.mean(abs(true - p) / abs(true))
    print(label + ' MRE:' + str(mre))
    print(label + ' R2:' + str(score))
    if local:
        results = file  + label + "_results.txt"
    else:
        results = file  + label + "_results.dat"

    with open(results, 'a') as f:
        df_string = prediction_df.to_string()
        f.write(df_string)


def writeResults2(file, values):
    if local:
        results = file + "_results.txt"
    else:
        results = file + "_results.dat"
    np.savetxt(results, values.detach().cpu().numpy())

def readResults(file):
    results = file + "_results.dat"
    data = np.loadtxt(results)
    data = data.reshape(data.size, 1)
    data = torch.tensor(data).float()
    data = data.to(device)
    return data

def printDebug():
    print()
    sft = dnn2.layers[0].shiftN.detach().cpu().numpy()
    scl = dnn2.layers[0].scaleN.detach().cpu().numpy()
    print('sftN=', sft)
    print('sclN=', scl)
    sft = dnn3.layers[0].shiftK.detach().cpu().numpy()
    scl = dnn3.layers[0].scaleK.detach().cpu().numpy()
    print('sftK=', sft)
    print('sclK=', scl)
    print('sep=', PINNmodel.sep)


def printResults(half, idx):
    predictionTensor = dnn(X_test[idx[0]])
    tempPrediction = unscaleValues(predictionTensor[:, 0], PINNmodel.tempShift, PINNmodel.tempScale)

    print()
    writeResults(tempPrediction, tempTest[idx[0]], filename + "_LBGFS_", "temp" + half)
    print()

    predictionTensor = dnn2(xOnly[idx[0]])
    nuPrediction = predictionTensor[:, 0]
    writeResults(nuPrediction, nuTrue[idx[0]], filename + "_LBGFS_", "nu" + half)
    print()

    predictionTensor = dnn3(xOnly[idx[0]])
    kappaPrediction = predictionTensor[:, 0]
    writeResults(kappaPrediction, kappaTrue[idx[0]], filename + "_LBGFS_", "kappa" + half)
    print()


# design of standard DNN; architecture can be changed easily for testing structural influence
class DNN(torch.nn.Module):
    def __init__(self, architecture):
        super(DNN, self).__init__()
        # deploy layers
        self.layers = torch.nn.Sequential(architecture)
    def forward(self, x):
        out = self.layers(x)
        return out

# design for multi material version of PINN
class PINN_LBFGS():
    def __init__(self, dose, x_ibc, x_bc, x_d, t_ibc, t_bc, t_d, temp_bc, temp_d, x_f, t_f, plot_grad=False):
        
        self.x_bc = x_bc
        self.x_ibc = x_ibc
        self.x_d = x_d
        self.x_f = x_f
        self.t_bc = t_bc
        self.t_ibc = t_ibc
        self.t_d = t_d
        self.t_f = t_f
        self.sep = 0.0
        self.idx = range(len(x_f))

        self.bTemp, self.tempShift, self.tempScale = scaleValues(temp_bc)
        self.dose = dose / self.tempScale
        mb = torch.mean(self.bTemp ** 2)

        self.kTrue, r, cp = get_const(x_f, constants, depths)
        self.nTrue = (10 ** nuScale) / (r * cp)
        mf = torch.mean(((self.dose) / (r * cp)) ** 2)
        self.dTemp = temp_d

        if len(temp_d > 0):
            self.dTemp = self.dTemp - self.tempShift
            self.dTemp = self.dTemp / self.tempScale
            md = torch.mean(self.dTemp ** 2)
            N = 3
            wsum = mb + mf + md
        else:
            N = 2
            wsum = mb + mf
         
        if len(temp_d) > 0:
            self.wd = (1 - md / wsum) / (N - 1)
        else:
            self.wd = 0
            md = 0
        self.wb = (1 - mb / wsum) / (N - 1)
        self.wf = (1 - mf / wsum) / (N - 1)


        print()
        print('temp boundary magnitude', mb)
        print('function magnitude', mf)
        print('data magnitude', md)
        print()
        print('temp boundary weight', self.wb)
        print('function weight', self.wf)
        print('data weight', self.wd)
        print()

        self.iter = 0


    def init_optimizer(self, adaptiveLR, dnn, dnn2, dnn3, parms):
        if parms == 1:
            self.optimizer = torch.optim.LBFGS(
#                list(dnn.parameters()) + list(dnn2.parameters()) + list(dnn3.parameters()),
                list(dnn.parameters()), 
                lr=adaptiveLR,
                max_iter=50000,
                max_eval=50000,
                history_size=50,
                tolerance_grad=1e-5,
                tolerance_change=1.0 * np.finfo(float).eps,
                line_search_fn="strong_wolfe")
        else:
            self.optimizer = torch.optim.LBFGS(
                list(dnn.parameters()) + list(dnn2.parameters()) + list(dnn3.parameters()),
#                list(dnn.parameters()) + list(dnn2.parameters()),
                lr=adaptiveLR,
                max_iter=50000,
                max_eval=50000,
                history_size=50,
                tolerance_grad=1e-5,
                tolerance_change=1.0 * np.finfo(float).eps,
                line_search_fn="strong_wolfe")

    def train(self):
        self.optimizer.step(lossFunction)


#Program Input
if len(sys.argv) > 1:
    local = False
    seed = sys.argv[1]
    N_d = int(sys.argv[2])
    nLayers = int(sys.argv[3])
    nNodes = int(sys.argv[4])
    model = sys.argv[5]
    adamEpoch = int(sys.argv[6])
    gpu = int(sys.argv[7])
    parmBound = int(sys.argv[8])
    path = '../pinn/'
    uxxtPath = '../pinn/all/secondpass/timedep/'
    parmName = sys.argv[9]
    smooth = int(sys.argv[10])
    noise = int(sys.argv[11])
    parmLayers = 0#int(sys.argv[12])
    parmNodes = 1#int(sys.argv[13])

else:
    local = True
    seed = 30
    N_d = 10000
    nLayers = 10
    nNodes = 32
    model = '2b'
    path = 'C:\jennydocs\code\inverse\pinn\\'
    uxxtPath = ''#'C:\jennydocs\code\inverse\pinn\\all\\uxx_ut\\'
    adamEpoch = 1
    gpu = 0
    parmBound = 0
    parmName = 'k'
    smooth = 1
    noise = 0
    parmLayers = 0
    parmNodes = 1


print('seed: ', seed)
print('data: ', N_d)
print('layers: ', nLayers)
print('layers2: ', parmLayers)
print('nodes: ', nNodes)
print('nodes2: ', parmNodes)
print('model: ', model)

print('adam epochs: ', adamEpoch)
print('noise: ', noise)


if gpu > 3:
    gpu = gpu - 4

if gpu == 0:
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
if gpu == 1:
    device = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")
if gpu == 2:
    device = torch.device("cuda:2" if torch.cuda.is_available() else "cpu")
if gpu == 3:
    device = torch.device("cuda:3" if torch.cuda.is_available() else "cpu")


print(device)


rng = default_rng(int(seed))
torch.cuda.manual_seed_all(int(seed))
torch.manual_seed(int(seed))


# Data Parameters for Training and Testing
N_i = 250
N_b = 250


# Model Parameters
structure = list()
structure.append(2)
for cNode in range(nLayers):
    structure.append(nNodes)
structure.append(1)

activation_fn = torch.nn.Tanh

# Training Data
kappa =  [0.235, 0.445, 0.185]
rho =    [1190, 1111, 971]
cp =     [3600, 3300, 2700]
depths = [0.0001, 0.0015, 0.0104]

epidermis = [kappa[0], rho[0], cp[0]]
dermis =	[kappa[1], rho[1], cp[1]]
fat = 		[kappa[2], rho[2], cp[2]]
constants = [epidermis, dermis, fat]

initScale = 0.0

if str(model) == '2f':
    depths = [0.0016, 0.0104]
    constants = [epidermis, fat]
    initScale = 0.1

if str(model) == '2a':
    depths = [0.0016, 0.0104]
    constants = [epidermis, dermis]
    initScale = 0.1


if str(model) == '2b':
    depths = [0.0016, 0.0104]
    constants = [dermis, fat]
    initScale = 0.1

if str(model) == '2bXL':
    depths = [0.0016, 0.0104]
    constants = [dermis, fat]
    initScale = 0.1


if str(model) == '2ba':
    depths = [0.001, 0.011]
    constants = [dermis, fat]
    initScale = 0.1


if str(model) == '2bc':
    depths = [0.0036, 0.0084]
    constants = [dermis, fat]
    initScale = 0.1


if str(model) == '2bb':
    depths = [0.0026, 0.0094]
    constants = [dermis, fat]
    initScale = 0.1

if str(model) == '2baXL':
    depths = [0.001, 0.011]
    constants = [dermis, fat]
    initScale = 0.1


if str(model) == '2bcXL':
    depths = [0.0036, 0.0084]
    constants = [dermis, fat]
    initScale = 0.1


if str(model) == '2bbXL':
    depths = [0.0026, 0.0094]
    constants = [dermis, fat]
    initScale = 0.1


if str(model) == '3':
    initScale = 0.1

if str(model) == '3b':
    depths = [0.0015, 0.0025, 0.008]
    initScale = 0.1


if str(model) == '3bXL':
    depths = [0.0015, 0.0025, 0.008]
    initScale = 0.1



if str(model) == '1':
    depths = [0.012]
#    N_f = 500_000
    constants = [dermis]

if str(model) == '1a':
    depths = [0.012]
#    N_f = 500_000
    constants = [epidermis]

if str(model) == '1b':
    depths = [0.012]
#    N_f = 500_000
    constants = [fat]

N_f = 100_000


filestring = "d_" + str(N_d) + "_L_" + str(nLayers) + "_N_" + str(nNodes) + "_A_" + str(adamEpoch) + "_p_" + str(parmBound) + "_S_" + str(model) + "_nk"# + str(parmName)
filename = str(seed) + "_" + filestring


nuScale = 6
kappaScale = 0

if noise == 0:
    tempTrain = np.loadtxt(path + 'tempTrain_' + str(model) + '.txt')
else:
    tempTrain = np.loadtxt(path + 'tempTrain_' + str(model) + '_' + str(noise) + '.txt')


tTrain = np.loadtxt(path + 'tTrain_' + str(model) + '.txt')
xTrain = np.loadtxt(path + 'xTrain_' + str(model) + '.txt')
doseTrain = np.loadtxt(path + 'doseTrain_' + str(model) + '.txt')

xMin = min(xTrain)
xMax = max(xTrain)

tMin = min(tTrain)
tMax = max(tTrain)

# Initial Conditions
idx = np.where(tTrain == 0)
trainIdx = rng.choice(np.asarray(idx).flatten(), N_i, replace = True)
btemp = tempTrain[trainIdx]
bdose = doseTrain[trainIdx]
ixt = np.vstack((xTrain[trainIdx], tTrain[trainIdx]))

# Boundaries
idx = np.where(xTrain == xMin)
trainIdx = rng.choice(np.asarray(idx).flatten(), N_b, replace = True)

idx = np.where(xTrain == xMax)
trainIdx = np.hstack((trainIdx, rng.choice(np.asarray(idx).flatten(), N_b, replace = True)))

ibcxt = np.vstack((xTrain[trainIdx], tTrain[trainIdx]))
btemp = np.hstack((btemp, tempTrain[trainIdx]))
bdose = np.hstack((bdose, doseTrain[trainIdx]))
ibcxt = np.hstack((ixt, ibcxt))

bcxt = np.vstack((xTrain[trainIdx], tTrain[trainIdx]))

# Function
# allow replacement because dose is involved
idx = rng.choice(xTrain.shape[0], N_f, replace=True)
idxx = xTrain[idx].reshape(N_f, 1)
idxt = tTrain[idx].reshape(N_f, 1)
col_points = np.hstack((idxx, idxt))
dose_f = doseTrain[idx]


# Data
idx = rng.choice(xTrain.shape[0], N_d, replace=True)
x_d = xTrain[idx].reshape(N_d, 1)
t_d = tTrain[idx].reshape(N_d, 1)
temp_d = tempTrain[idx]
x_d = torch.tensor(x_d, requires_grad=True).float()
t_d = torch.tensor(t_d, requires_grad=True).float()
temp_d = temp_d.reshape(temp_d.size, 1)
temp_d = torch.tensor(temp_d).float()

bcxt = np.transpose(bcxt)
ibcxt = np.transpose(ibcxt)
btemp = btemp.reshape(btemp.size, 1)

# combine collocation points and initial and boundary condition points to include icbc points in col points
col_points = np.vstack((col_points, ibcxt))
col_dose = np.hstack((dose_f, bdose))

bdose = bdose.reshape(bdose.size, 1)
col_dose = col_dose.reshape(col_dose.size, 1)

# separate x from t and create tensors from them, with grad when applicable
x_bc = torch.tensor(bcxt[:, 0:1], requires_grad=True).float()
t_bc = torch.tensor(bcxt[:, 1:2], requires_grad=True).float()
x_ibc = torch.tensor(ibcxt[:, 0:1], requires_grad=True).float()
t_ibc = torch.tensor(ibcxt[:, 1:2], requires_grad=True).float()
temp_bc = torch.tensor(btemp).float()
x_f = torch.tensor(col_points[:, 0:1], requires_grad=True).float()
t_f = torch.tensor(col_points[:, 1:2], requires_grad=True).float()
dose = torch.tensor(col_dose).float()

x_fParm = x_f

x_bc = x_bc.to(device)
t_bc = t_bc.to(device)
x_ibc = x_ibc.to(device)
t_ibc = t_ibc.to(device)
x_f = x_f.to(device)
t_f = t_f.to(device)
x_d = x_d.to(device)
t_d = t_d.to(device)
temp_bc = temp_bc.to(device)
temp_d = temp_d.to(device)
dose = dose.to(device)

print('seed: ', seed)

tempTest = np.loadtxt(path + 'tempTest_' + str(model) + '.txt')
tTest = np.loadtxt(path + 'tTest_' + str(model) + '.txt')
xTest = np.loadtxt(path + 'xTest_' + str(model) + '.txt')

X_test = np.hstack((xTest.reshape(xTest.size, 1), tTest.reshape(xTest.size, 1)))
X_test = torch.tensor(X_test).float()
X_test = X_test.to(device)

xOnly = X_test[:, 0]
xOnly = xOnly.reshape(len(xOnly), 1)

kappaTrue, rhoTrue, cpTrue = get_const(X_test[:, 0], constants, depths)
kappaTrue = kappaTrue.detach().cpu().numpy() * (10 ** kappaScale)
rhoTrue = rhoTrue.detach().cpu().numpy()
cpTrue = cpTrue.detach().cpu().numpy()
nuTrue = (10 ** nuScale) / (rhoTrue * cpTrue)



PINNmodel = PINN_LBFGS(dose, x_ibc, x_bc, x_d, t_ibc, t_bc, t_d, temp_bc, temp_d, x_f, t_f, plot_grad=False)

# loop through structure and form dictionary of desired architecture
layers = list()
for i in range(len(structure)-2):
    layers.append((f'layer_{i+1}', torch.nn.Linear(structure[i], structure[i+1])))
    layers.append((f'activation_{i+1}', activation_fn()))
layers.append((f'layer_{len(structure)-1}', torch.nn.Linear(structure[-2], structure[-1])))
architecture = OrderedDict(layers)

dnn = DNN(architecture)
dnn.to(device)

structure = list()
structure.append(1)
structure.append(2)
activationN = SigmoidSeparationN(shiftN=0.5, scaleN=initScale, separation=0.0)
layers = list()
layers.append((f'layer_{len(structure) - 1}', activationN))
architecture = OrderedDict(layers)
dnn2 = DNN(architecture)
dnn2.to(device)

activationK = SigmoidSeparationK(shiftK=0.0, scaleK=initScale)
layers = list()
layers.append((f'layer_{len(structure) - 1}', activationK))
architecture = OrderedDict(layers)
dnn3 = DNN(architecture)
dnn3.to(device)

optimizer = torch.optim.Adam(
    dnn.parameters(),
    lr = 0.001
)
optimizer2 = torch.optim.Adam(
    dnn2.parameters(),
    lr = 0.0001
)
optimizer3 = torch.optim.Adam(
    dnn3.parameters(),
    lr = 0.0001
)

for iter in range(0, adamEpoch):
    lossFunction()
    optimizer.step()
    lossFunctionNu()
    optimizer2.step()
    lossFunctionKappa()
    optimizer3.step()

printDebug()



if PINNmodel.sep <= 0.0 or PINNmodel.sep > 0.12:
    print('SINGLE MATERIAL')
    optimizer.param_groups[0]['lr'] = 0.0001
    optimizer2.param_groups[0]['lr'] = 0.00001

    adamEpochSmall = int(adamEpoch / 5)
    
    for learningRate in [0.1, 0.01, 0.001, 0.0001, 0.00001]:
        optimizer3.param_groups[0]['lr'] = learningRate
        for iter in range(0, adamEpochSmall):
            lossFunction()
            optimizer.step()
            lossFunctionNu()
            optimizer2.step()
            lossFunctionKappa()
            optimizer3.step()
        printDebug()
    printResults("ALL", np.where(xOnly.cpu().detach().numpy() <= 1))

else:

    adamEpochSmall = int(adamEpoch / 5)

    optimizer.param_groups[0]['lr'] = 0.0001
    optimizer2.param_groups[0]['lr'] = 0.00001

    sftN = dnn2.layers[0].shiftN.detach().cpu().numpy()
    sclN = dnn2.layers[0].scaleN.detach().cpu().numpy()
    sftK = dnn3.layers[0].shiftK.detach().cpu().numpy()
    sclK = dnn3.layers[0].scaleK.detach().cpu().numpy()

    saveSep = np.array(PINNmodel.sep)
    h = saveSep.reshape(1, 1)
    np.savetxt(filename + "_sep.dat", h)


  
    print('SECOND SIMULATION - FIRST HALF')
    idx1 = np.where(PINNmodel.x_f.cpu().detach().numpy() <= saveSep)
    PINNmodel.idx = idx1
    activationN.scaleN = torch.nn.Parameter(torch.tensor(0.0).to(device))
    activationK.scaleK = torch.nn.Parameter(torch.tensor(0.0).to(device))
    activationN.separation = torch.nn.Parameter(torch.tensor(0.0).to(device))
    
    for learningRate in [0.1, 0.01, 0.001, 0.0001, 0.00001]:
        optimizer3.param_groups[0]['lr'] = learningRate

        for iter in range(0, adamEpochSmall):
            lossFunction()
            optimizer.step()
            lossFunctionNu()
            optimizer2.step()
            lossFunctionKappa()
            optimizer3.step()
        printDebug()
   
   
    printResults("1", np.where(xOnly.cpu().detach().numpy() <= saveSep))


    print('SECOND SIMULATION - SECOND HALF')
    idx2 = np.where(PINNmodel.x_f.cpu().detach().numpy() >= saveSep)
    PINNmodel.idx = idx2

    structure = list()
    structure.append(1)
    structure.append(2)
    newShiftN = sftN + sclN
    activationN = SigmoidSeparationN(shiftN=newShiftN, scaleN=0.0, separation=0.0)
    layers = list()
    layers.append((f'layer_{len(structure) - 1}', activationN))
    architecture = OrderedDict(layers)
    dnn2 = DNN(architecture)
    dnn2.to(device)

    newShiftK = sftK + sclK
    print('newshiftk ', newShiftK)
    activationK = SigmoidSeparationK(shiftK=newShiftK, scaleK=0.0)
    layers = list()
    layers.append((f'layer_{len(structure) - 1}', activationK))
    architecture = OrderedDict(layers)
    dnn3 = DNN(architecture)
    dnn3.to(device)

    optimizer2 = torch.optim.Adam(
        dnn2.parameters(),
        lr = 0.0001
    )
    optimizer3 = torch.optim.Adam(
        dnn3.parameters(),
        lr = 0.00001
    )



    for learningRate in [0.1, 0.01, 0.001, 0.0001, 0.00001]:
        optimizer3.param_groups[0]['lr'] = learningRate

        for iter in range(0, adamEpochSmall):
            lossFunction()
            optimizer.step()
            lossFunctionNu()
            optimizer2.step()
            lossFunctionKappa()
            optimizer3.step()
        printDebug() 


    printResults("2", np.where(xOnly.cpu().detach().numpy() >= saveSep))



