#!/bin/bash
g=1
for N in 32 
do
	for d in 1000
	do
		for m in 2baXL 2bbXL
		do 
			for nk in nk
			do
				for a in 25000 
				do
					bash skinpdeSep3.sh $d $a $g $nk $m $N &
					g=$(( g + 1 ))
				done
			done
		done	
	done    
done
