clear
addpath('C:\jennydocs\code\pdfeMatlab\2d');
publicationQuality();
datapath = 'C:\jennydocs\code\pinn\';

plotSurf = 1;
writeFiles = 0;

skinModels = {'1aXL', '1XL', '1bXL', '2baXL', '2bXL', '2bbXL', '2bcXL'}; 
skinModels = {'2bbXL'}
nSkinModels = length(skinModels);


noiseLevels = [2, 6, 10];
nNoise = length(noiseLevels);

for cSkinModel = 1:nSkinModels
    skinModel = skinModels{cSkinModel};
    tempTrain = readmatrix([datapath, 'tempTrain_', skinModel, '.txt']);
    if plotSurf
        xTrain = readmatrix([datapath, 'xTrain_', skinModel, '.txt']);
        tTrain = readmatrix([datapath, 'tTrain_', skinModel, '.txt']);
        x = sort(unique(xTrain));
        t = sort(unique(tTrain));
        nX = length(x);
        nT = length(t);
        [X, T] = meshgrid(x, t); 
    end
    for noiseLevel = noiseLevels
        tempTrain = tempTrain + noiseLevel * normrnd(0, 1, size(tempTrain));
        if plotSurf
            figure
            trueGrid = griddata(xTrain, tTrain, tempTrain, X, T);
            surf(X, T, trueGrid, 'edgecolor', 'interp');  
            colormap(jet)       
            colorbar
            clim([300 450])
            xlabel('Depth');
            ylabel('Time');
            zlabel('Temperature');
            title(['Noise Level ', num2str(noiseLevel)]);
            zlim([250 500])
            view(-12, 30);
        end
        if writeFiles
            writematrix(tempTrain, [datapath, 'tempTrain_', skinModel, '_', num2str(noiseLevel), '.txt']);
        end
    end
end