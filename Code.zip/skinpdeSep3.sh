#!/bin/bash

n=0
sm=0
p=0
d=$1
a=$2
g=$3
nk=$4
m=$5
N=$6
	

for s in $(seq 1 1);
do
	python3 3netsSep3.py $s $d 10 $N $m $a $g $p $nk $sm $n >> d_sep_"$d"_L_10_N_"$N"_A_"$a"_p_"$p"_S_"$m"_"$nk".txt 2>> error.txt
done