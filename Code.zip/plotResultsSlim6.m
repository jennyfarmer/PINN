
clear
addpath('C:\jennydocs\code\pdfeMatlab\2d');
publicationQuality();
path = 'C:\jennydocs\code\inverse\pinn\all\secondpass\timedep\'; %best for d=5000
path = 'C:\jennydocs\code\inverse\pinn\all\secondpass\timedep\t9\'; %t9 best
% path = 'C:\jennydocs\code\inverse\new\separateparm\';
% path = 'C:\jennydocs\code\inverse\new\noparm\';
% path = 'C:\jennydocs\code\inverse\new\noparmXNK\';
path = 'C:\jennydocs\code\inverse\new\nf100_000\';
path = 'C:\jennydocs\code\inverse\3net\fresh3\';
% path = 'C:\jennydocs\code\inverse\new\';

datapath = 'C:\jennydocs\code\pinn\';

saveTable1 = 0; % one layer, 1a, 1, 1b, nu and kappa
saveTable2 = 0; %temp, small one in figure 1a, 1, 1b
saveTable3 = 1; %model 2bbxl,all2bxl models?, nu and kappa
saveTable4 = 0; % boundaries. all four 2b models, nu only

scaleParmNu = 6;
scaleParmKappa = 0;

plotPDFParm = 0;
plotBoxesParm = 0;
plotHistParm = 0;
plotBoxes = 0;
plotBoxesByLayer = 0;
plotPDFsep = 0;
plotSliceScatter = 0;
plotMRElocation = 0;
plotSurfSTD = 0;
plotPDFParm2 = 0;
plotSurf = 0;

if plotBoxesParm || plotHistParm
    figure
    hold on
end

writeXNK = 0;

r2Outlier = -10e50;
mseOutlier = 500000000;%2.3;%0.1;

green = [0, 0.7, 0.24];
grey = [0.74,0.77,0.71];
grey1 = [0.95,0.95,0.95];
grey1 = [0.85,0.85,0.85];
grey2 = [0.75,0.75,0.75];
grey3 = [0.65,0.65,0.65];
blue = [0 0.4470 0.7410];
red = [0.6350 0.0780 0.1840];
greys = vertcat(grey1, grey2, grey3);

matlabblue   = [0, 0.4470, 0.7410];
matlaborange = [0.8500, 0.3250, 0.0980];
matlabyellow = [0.9290, 0.6940, 0.1250];
matlabpurple = [0.4940, 0.1840, 0.5560];
matlabgreen = [0.4660, 0.6740, 0.1880];
matlabcyan = [0.3010, 0.7450, 0.9330];  
matlabred = [0.6350, 0.0780, 0.1840];  
matlabblack = [0, 0, 0];
purple = [176, 0 155];
colors = vertcat(matlabgreen, matlabred, matlabblue, matlabcyan,  matlabpurple, matlaborange,...
                matlabyellow);
runs = [1:10];
nRuns = length(runs);

parameter = '_nk_';
optimizer = 'LBGFS_';

parmdatas = [0];% 1000 10000];
nParmdata = length(parmdatas);

epochs = [25000];
nEpochs = length(epochs);

testLength = 100000;
skinModels = {'1a', '1', '1b'};%, '1b'};
skinModels = {'2baXL', '2bXL', '2bbXL', '2bcXL'};%, '1aXL', '1XL', '1bXL'};
% skinModels = {'2bbXL'};%, '2bb'};
% modelNames = {'Epidermis', 'Dermis', 'Fat'};
modelNames = {'Dermis/Fat', 'Dermis/Fat', 'Dermis/Fat', 'Dermis/Fat'};
boundaries = [0.001, 0.0016, 0.0026, 0.0036];
nuConstants = [0.233427, 0.272755, 0.381432];
kappaConstants = [0.235, 0.445, 0.185];
nSkinModels = length(skinModels);

noiseLevel = [0]%, 2, 6, 10];
nNoise = length(noiseLevel);

models = {'nu'};
% models = {'nu', 'kappa', 'temp'};
% models = {'kappa', 'temp'};
models = {'nu', 'kappa'};
% models = {'kappa'};
% models = {'temp'};
nModels = length(models);

dataPoints = [1000];
nDataPoints = length(dataPoints);

nTests = nModels * nDataPoints * nNoise * nSkinModels * nEpochs;

r2 = zeros(nRuns, nTests);
MSE = zeros(nRuns, nTests);
MRE = zeros(nRuns, nTests);
L1 = zeros(nRuns, nTests);
avgPredicts = zeros(nRuns, nTests);
modes = zeros(nTests, 1);
testNames = cell(nTests, 8);
thresholds = zeros(nRuns, nTests);
cTest = 0;
allMRE = zeros(100000, nTests);

for cSkinModel = 1:nSkinModels
    skinModel = skinModels{cSkinModel};

    xTest = readmatrix([datapath, 'xTest_', skinModel, '.txt']);
    tTest = readmatrix([datapath, 'tTest_', skinModel, '.txt']);

    timeThreshold = 1;%0.0005;
    testLength = length(xTest);

    xTrain = readmatrix([datapath, 'xTrain_', skinModel, '.txt']);
    tTrain = readmatrix([datapath, 'tTrain_', skinModel, '.txt']);
    tempTrain = readmatrix([datapath, 'tempTrain_', skinModel, '.txt']);

    x = sort(unique(xTrain));
    t = sort(unique(tTrain));
    t = t(find(t <= timeThreshold));

    for epoch = epochs
        for dataPoint = dataPoints
            for cModel = 1:nModels
                model = models{cModel};
                if contains(model, 'nu') || contains(model, 'kappa') || contains(model, 'alpha')
                    modelParm = true;
                else
                    modelParm = false;
                end                                        
                for cNoise = 1:nNoise
                    if noiseLevel(cNoise) == 0
                        noiseString = '';
                    else
                        noiseString = ['n_', num2str(noiseLevel(cNoise)), '_'];
                    end
                    cTest = cTest + 1;
                    xRange = readmatrix([datapath, 'xRange.txt']);
                    if length(strfind(model, 'nu')) > 0
                       trueCol1 = readmatrix([datapath, 'cp', '_', skinModel, '.txt']);
                       trueCol2 = readmatrix([datapath, 'rho', '_', skinModel, '.txt']);
                       trueCol = 10^scaleParmNu ./ (trueCol1 .* trueCol2);
                       trueCol = interp1(xRange, trueCol, x);                      
                    elseif length(strfind(model, 'kappa')) > 0
                       trueCol = 10^scaleParmKappa .* readmatrix([datapath, model, '_', skinModel, '.txt']);              
                       trueCol = interp1(xRange, trueCol, x);                                   
                    else
                       trueCol = readmatrix([datapath, model, 'Train_', skinModel, '.txt']);
                    end
        
                    predictPoints = zeros(nRuns, testLength);
                    mre = zeros(testLength, 1);
                    nActualRuns = 0;
                    for i = runs
                        fileBase = [path, num2str(i), '_', 'd_', num2str(dataPoint),...
                            '_L_10_N_32', '_A_', num2str(epoch) '_p_0', '_S_', skinModel, parameter,...
                              noiseString]; 
                        fileString = [fileBase, 'sep.dat'];
                        sepFile = dir(fileString);
                        if length(sepFile) > 0
%                        if skinModel(1) == '2'
                            sep = readmatrix(fileString);
                            thresholds(i, cTest) = sep;

                            fileString = [fileBase, optimizer, model, '1_results.dat'];             
                            file = dir(fileString);
                            if length(file) ~= 1
                                out = 1;
                                disp(['problem with file: ', fileString]);
                            else
                                M1 = readmatrix([path, file(1).name]); 
                            end
                            fileString = [fileBase, optimizer, model, '2_results.dat'];             
                            file = dir(fileString);
                            if length(file) ~= 1
                                out = 1;
                                disp(['problem with file: ', fileString]);
                            else
                                M2 = readmatrix([path, file(1).name]); 
                            end
                            M = [M1; M2];
                            idxM1 = find(xTest < sep);
                            idxM2 = find(xTest > sep);
                            xTest = [xTest(idxM1); xTest(idxM2)];
                            tTest = [tTest(idxM1); tTest(idxM2)];
                        else
                            fileString = [fileBase, optimizer, model, 'ALL_results.dat']
                            file = dir(fileString);
                            if length(file) ~= 1
                                out = 1;
                                disp(['problem with file: ', fileString]);
                            else
                                M = readmatrix([path, file(1).name]); 
                            end
                        end                     


                        predict = M(:, 2);
                        predictPoints(i, :) = predict;
                        true = M(:, 3);
                        tempPredict = [];
                        r2(i, cTest) = 1 - sum((predict(:) - true(:)) .^ 2) ./ sum((predict(:) - mean(predict(:))) .^ 2);
                        MSE(i, cTest) = mean((predict(:) - true(:)) .^ 2);
                        MRE(i, cTest) = mean(abs(predict(:) - true(:)) ./ true(:));
                        L1(i, cTest) = mean(abs(predict(:) - true(:)));
                        out1 = r2(i, cTest) <= r2Outlier;                              
                        out2 = MSE(i, cTest) >= mseOutlier;                              
                        out = out1 || out2;            
                    
                        if ~out
                            nActualRuns = nActualRuns + 1;
                            mre = mre + abs(predict - true) ./ abs(true);
                            idxGood(nActualRuns) = i;                    
                        end                
                    end
                    averagePredicts = mean(predictPoints, 2);

                    testNames{cTest, 1} = model;
                    testNames{cTest, 2} = dataPoint;
                    testNames{cTest, 3} = skinModel;
                    testNames{cTest, 4} = epoch;
                    testNames{cTest, 5} = mean(MRE(:, cTest));
                    testNames{cTest, 6} = mean(averagePredicts);
                    testNames{cTest, 7} = std(averagePredicts);
                    testNames{cTest, 8} = std(MRE(:, cTest));

                    bx = zeros(nActualRuns, 1);
                    avgB1 = zeros(nActualRuns, 1);
                    avgB2 = zeros(nActualRuns, 1);
                    stdB1 = zeros(nActualRuns, 1);
                    stdB2 = zeros(nActualRuns, 1);
                    mreB1 = zeros(nActualRuns, 1);
                    mreB2 = zeros(nActualRuns, 1);
                    for b = runs
                        bx(b) = find(xTest < thresholds(b, cTest), 1, 'last');
                        avgB1(b) = mean(predictPoints(b, 1:bx(b)));
                        avgB2(b) = mean(predictPoints(b, (bx(b) + 1: end)));
                        stdB1(b) = std(predictPoints(b, 1:bx(b)));
                        stdB2(b) = std(predictPoints(b, (bx(b) + 1: end)));

                        mreB1(b) = abs(avgB1(b) - true(1)) ./ true(1);
                        mreB2(b) = abs(avgB2(b) - true(end)) ./ true(end);
                    end

                    testNames{cTest, 9} = mean(avgB1(runs));
                    testNames{cTest, 10} = std(avgB1(runs));
                    testNames{cTest, 11} = mean(avgB2(runs));
                    testNames{cTest, 12} = std(avgB2(runs));
                    testNames{cTest, 13} = mean(mreB1(runs));
                    testNames{cTest, 14} = std(mreB1(runs));
                    testNames{cTest, 15} = mean(mreB2(runs));
                    testNames{cTest, 16} = std(mreB2(runs));
                    testNames{cTest, 17} = mean(thresholds(runs, cSkinModel));
                    testNames{cTest, 18} = std(thresholds(runs, cSkinModel));
                    testNames{cTest, 19} = abs(mean(thresholds(runs, cSkinModel))...
                                           - boundaries(cSkinModel)) ./ boundaries(cSkinModel);
                    

                    mre = mre / nActualRuns; 
                    allMRE(:, cTest) = mre;                  
                             
                    if nActualRuns == 0
                        disp('No valid data');
                    end

                    if plotSliceScatter && nActualRuns > 0
                        figure
                        hold on
                        avgPoints = median(predictPoints(idxGood, :), 1);
                        stdPoints = std(predictPoints(idxGood, :), 1);
                        if modelParm 
                            timeSlices = 1;
                        else
                            timeSlices = [0.0, 0.1, 0.3, 0.9995];
                        end
                        for tSlice = timeSlices
                            if modelParm
                                idxTrue = find(tTrain <= tSlice);
                            else
                                idxTrue = find(tTrain == tSlice);
                            end
                            trueScatter = tempTrain(idxTrue);
                            trueX = xTrain(idxTrue);
                            trueMatrix = [trueX, trueScatter];
                            trueMatrix = sortrows(trueMatrix, 1);
                       
                            if modelParm 
                                idxPredict = find(tTest <= tSlice);
                            else
                                idxPredict = find(tTest == tSlice);
                            end
                            predictScatter = avgPoints(idxPredict);
                            if nActualRuns > 1
                                stdScatter = stdPoints(idxPredict);
                            else
                                stdScatter = zeros(1, length(idxPredict));
                            end
                            predictX = xTest(idxPredict);
                            predictMatrix = [predictX, predictScatter', stdScatter'];
                            predictMatrix = sortrows(predictMatrix, 1);                            
                            
                            if modelParm
                                yup = predictMatrix(:, 2) + 2 * predictMatrix(:, 3);
                                ydown = predictMatrix(:, 2) - 2 * predictMatrix(:, 3);  
                                xax = predictMatrix(:, 1)'; 
                                ydown(isnan(ydown)) = 0;
                                yup(isnan(yup)) = 0;
                                patch([xax fliplr(xax)], [ydown' fliplr(yup')], grey, 'edgecolor', 'none');
                                plot(x, trueCol, 'color', matlabblue, 'color', matlabblue);
                                plot(predictMatrix(:, 1), predictMatrix(:, 2), 'color', 'black')
                                legend('Uncertainty', 'Exact', 'Average prediction');
                            else
                                plot(predictMatrix(:, 1), predictMatrix(:, 2), '.', 'color', 'black', 'markersize', 20);
                                plot(trueMatrix(:, 1), trueMatrix(:, 2), 'color', matlabblue);
                                legend('predicted values', 'exact');
                                ylabel('Temperature');
                            end
                                   
                            xlabel('Depth');
                            ylabel(['\', model]);
                        end
                    end

                    if plotBoxesParm
                        boxchart(predictPoints(:));
                    end

                    if plotSurf
                        figure
%                        z = mean(predictPoints', 2);
                        z = predictPoints(i, :);
                        z = z';
                        scatter3(xTest, tTest, z, ones(length(z), 1) * 20, z, 'filled');
                        view(-12, 30);
                        colormap(jet) 
                        colorbar
                        xlabel('Depth (m)');
                        ylabel('Time (s)');
                        if length(strfind(model, 'nu')) > 0    
                            zlabel('\nu');   
                            zlim([0.2 0.4])
                        elseif length(strfind(model, 'kappa')) > 0
                            zlim([0.1 0.4])
                            zlabel('\kappa');
                        else
                            zlim([250 500])
                            zlabel('Temperature');
                            clim([300 450])
                        end
                        if noiseLevel(cNoise) > 0
                            title(['Predicted']);
%                             title(['Noise Level ', num2str(noiseLevel(cNoise))]);
                        end
                    end

                    if plotPDFParm && nActualRuns > 0
                        struct.SURDmin = 30;
                        struct.LagrangeMax = 3;
                        struct.debug = 0;
                        [f, y, py] = EstimatePDF(averagePredicts, struct);
                        [~, idx] = max(py);
                        modes(cTest) = y(idx);
                        figure
                        hold on
                        plot(y, py, 'color', colors(cSkinModel, :));
%                     plot([trueCol(1) trueCol(1)], [0 max(py)], '-', 'color', colors(cSkinModel, :));%'black');%, 'HandleVisibility','off')
%                     plot([modes(cTest) modes(cTest)], [0 max(py)], '--', 'color', colors(cSkinModel, :));%, 'HandleVisibility','off')
                        xlabel(models{cModel});
                        ylabel('probability density');
%                     legend('distribution', 'true', 'predict');
%                     title([num2str(modelNames{cSkinModel})]);
                        error1 = abs(trueCol(1) - modes(cTest)) / trueCol(1)
                        error2 = abs(trueCol(1) - mean(averagePredicts)) / trueCol(1)
%                     text(0, max(py), ['error = ', num2str(error)]);
                    end
                    if plotHistParm
                        histogram(predictPoints(:));
                    end

                    if plotPDFParm2 && nActualRuns > 0
                        figure
                        hold on
                        nu1 = [];
                        nu2 = [];
                        struct.SURDmin = 30;
                        struct.LagrangeMax = 7;
                        struct.debug = 0;
                        for i = 1:nRuns
                            idx = xTest < thresholds(i);
                            nu1 = horzcat(nu1, predictPoints(i, find(idx)));
                            nu2 = horzcat(nu2, predictPoints(i, find(~idx)));
                        end
                        [f1, y1, py1] = EstimatePDF(nu1, struct);
                        plot(y1, py1, 'color', colors(1, :));
                        [f, y2, py2] = EstimatePDF(nu2, struct);
                        plot(y2, py2, 'color', colors(2, :));                    
                        plot([trueCol(1) trueCol(1)], [0 max(py1)], '-', 'color', 'black');
                        plot([trueCol(end) trueCol(end)], [0 max(py2)], '-', 'color', 'black');
                        plot([mean(nu1) mean(nu1)], [0 max(py1)], '--', 'color', colors(1, :));
                        plot([mean(nu2) mean(nu2)], [0 max(py2)], '--', 'color', colors(2, :));
    
                        error = abs(trueCol(1) - mean(nu1)) / trueCol(1)
%                     text(min(py1), max(py1), ['error = ', num2str(error)]);
%                    text(0.28, 100, ['error = ', num2str(error)]);%nu
                        text(0.4, 6, ['error = ', num2str(error)]); %kappa
                        error = abs(trueCol(end) - mean(nu2)) / trueCol(end)
%                     text(min(py2), max(py2), ['error = ', num2str(error)]);
%                    text(0.33, 60, ['error = ', num2str(error)]); %nu

                        text(0.3, 10, ['error = ', num2str(error)]);%kappa                   
                        xlabel(models{cModel});
                        ylabel('probability density')
                        xlabel('depth')
                    end


    if plotMRElocation
        uq = unique(xTest);
        uql = length(uq);
        mreByX = zeros(uql, 1);
        stdByX = zeros(uql, 1);
        for i = 1:uql
            j = (xTest == uq(i));
            mreByX(i) = mean(mre(j));
            stdByX(i) = std(mre(j));
        end

        figure
        hold on
        yup = mreByX + 2 * stdByX;
        ydown = mreByX - 2 * stdByX;  

        xax = uq';                                 
        patch([xax fliplr(xax)], [ydown' fliplr(yup')], grey, 'edgecolor', 'none');
        plot(uq, mreByX, 'color', 'black');
        xlabel('Depth');
        ylabel('MRE')
        legend('Uncertainty', 'Average MRE');

        uq = unique(tTest);
        uq = uq(1:10:end);
        uql = length(uq);
        mreByX = zeros(uql, 1);
        stdByX = zeros(uql, 1);
        for i = 1:uql
            j = (tTest == uq(i));
            mreByX(i) = mean(mre(j));
            stdByX(i) = std(mre(j));
        end

%         figure
%         hold on
%         yup = mreByX + 2 * stdByX;
%         ydown = mreByX - 2 * stdByX;  
%         xax = uq';                                 
%         patch([xax fliplr(xax)], [ydown' fliplr(yup')], grey, 'edgecolor', 'none');
%         plot(uq, mreByX, 'color', 'black');
%         xlabel('Time');
%         ylabel('MRE')
%         legend('Uncertainty', 'Average MRE');

    end
                end
            end
        end                         
    end
    if plotSurfSTD
        figure
        scatter3(xTest, tTest, std(predictPoints), ones(length(predict), 1) * 20, std(predictPoints), 'filled')
        xlabel('depth');
        ylabel('time');
        zlabel('uncertainty');
        view(-11,40)
        colorbar
    end

end

if saveTable2
    fid = fopen([path, 'tableTemp.txt'], 'a');
    for count = 1:nSkinModels
        fprintf(fid,...
         '%s & %4.4e \x00B1 %4.4e \\\\ \n',...
          modelNames{count},...          
          testNames{count, 5}, testNames{count, 8});
    end
    fclose(fid); 
end

if saveTable1       
    fid = fopen([path, 'tableNu.txt'], 'a');
    for count = 1:nSkinModels
        c = 2 * (count - 1) + 1;
        fprintf(fid,...
         '%s & %4.4e & %4.4e \x00B1 %4.4e & %4.4e \\\\ \n',...
          modelNames{count},...
          nuConstants(count) * 10 ^ -scaleParmNu,...  
          testNames{c, 6} * 10 ^ -scaleParmNu, testNames{c, 7} * 10 ^ -scaleParmNu,... 
          testNames{c, 5});
    end
    fclose(fid);    
    fid = fopen([path, 'tableKappa.txt'], 'a');
    for count = 1:nSkinModels
        c = 2 * (count - 1) + 1;
        c1 = c + 1;
        fprintf(fid,...
         '%s & %4.4f & %4.4f \x00B1 %4.4f & %4.4f  \\\\ \n',...
          modelNames{count},...          
          kappaConstants(count) * 10 ^ -scaleParmKappa,...  
          testNames{c1, 6}, testNames{c1, 7},... 
          testNames{c1, 5});
    end
    fclose(fid);    
end  


if saveTable3       
    fid = fopen([path, 'tableNu2.txt'], 'a');
    for count = 1:nSkinModels
        c = 2 * (count - 1) + 1;
        fprintf(fid,...
         'Dermis &  %4.1f & %4.4e & %4.4e \x00B1 %4.4e & %4.4e \\\\ \n',...
          boundaries(count) * 10^3, nuConstants(2) * 10 ^ -scaleParmNu,...  
          testNames{c, 9} * 10 ^ -scaleParmNu, testNames{c, 10} * 10 ^ -scaleParmNu,... 
          testNames{c, 13});  
        fprintf(fid,...
         'Fat & & %4.4e & %4.4e \x00B1 %4.4e & %4.4e \\\\ \n',...
          nuConstants(3) * 10 ^ -scaleParmNu,...  
          testNames{c, 11} * 10 ^ -scaleParmNu, testNames{c, 12} * 10 ^ -scaleParmNu,... 
          testNames{c, 15});  
    end
    fclose(fid);    

    fid = fopen([path, 'tableKappa2.txt'], 'a');
    for count = 1:nSkinModels
        c = 2 * (count - 1) + 1;
        c1 = c + 1;
        fprintf(fid,...
         'Dermis & %4.1f & %4.4f & %4.4f \x00B1 %4.4e & %4.4f \\\\ \n',...
          boundaries(count) * 10^3, kappaConstants(2),...  
          testNames{c1, 9}, testNames{c1, 10},... 
          testNames{c1, 13});  
        fprintf(fid,...
         'Fat &  & %4.4f & %4.4f \x00B1 %4.4e & %4.4f \\\\ \n',...
          kappaConstants(3),...  
          testNames{c1, 11}, testNames{c1, 12},... 
          testNames{c1, 15});    
    end
    fclose(fid);    
end  

if saveTable4       
    fid = fopen([path, 'tableBoundary2.txt'], 'a');
    for count = 1:nSkinModels
        fprintf(fid,...
             '%4.4f & %4.4f \x00B1 %4.4f & %4.4f \\\\ \n',...
              boundaries(count) * 10 ^ 3,...  
              testNames{count, 17} * 10 ^ 3, testNames{count, 18} * 10 ^ 3,... 
              testNames{count, 19});  
    end
    fclose(fid);    
end  

if plotBoxesByLayer
    find(xTest < thresholds(b, 1), 1, 'last');
end

if plotBoxes
    figure
    boxchart(MRE(:, 1:4))
    xticklabels({'0', '2', '6', '10'});
    xlabel('Noise level');
    ylabel('MRE')
    title('Temperature predictions');
   
    figure
    boxchart(MRE(:, 5:8))
    xticklabels({'0', '2', '6', '10'});
    xlabel('Noise level');
    ylabel('MRE')
    title('\kappa predictions');

    figure
    boxchart(MRE(:, 9:12))
    xticklabels({'0', '2', '6', '10'});
    xlabel('Noise level');
    ylabel('MRE')
    title('\nu predictions');
end

if plotPDFsep && nActualRuns > 0
    figure
    hold on
    struct.SURDmin = 30;
    struct.LagrangeMax = 7;
    for i = 1:nTests
        [f, y, py] = EstimatePDF(thresholds(:, i), struct);
        plot(y, py);
    end
    xlabel(models{cModel});
    ylabel('probability density')
    xlabel('depth')
end